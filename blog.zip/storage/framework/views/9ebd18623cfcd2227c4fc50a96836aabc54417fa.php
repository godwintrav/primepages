

    <?php $__env->startSection('content'); ?>
    <script src='https://cdn.tiny.cloud/1/sk646bkxncso3iy9fd2f431wkxkm57j47b6apa3uwweq3xjn/tinymce/5/tinymce.min.js' referrerpolicy="origin">
    </script>
    <script>
        tinymce.init({
        selector: '#description'
        });
    </script>
    <div class="content">
        <div class="py-4 px-3 px-md-4">
            <div class="card mb-3 mb-md-4">

                <div class="card-body">
                    <!-- Breadcrumb -->
                    <nav class="d-none d-md-block" aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">
                                <a href="#">Posts</a>
                            </li>
                            <li class="breadcrumb-item active" aria-current="page">Edit Post</li>
                        </ol>
                    </nav>
                    <!-- End Breadcrumb -->

                    <div class="mb-3 mb-md-4 d-flex justify-content-between">
                        <div class="h3 mb-0">Edit Post</div>
                    </div>


                    <!-- Form -->
                    <div>
                        <form method="post" action="/admin/edit-post/<?php echo e($post->id); ?>" enctype="multipart/form-data">
                        	<div style="margin-bottom: 10px;" class="form-row">
                                <label for="title">Title</label>
                                <input type="text" class="form-control" value="<?php echo e($post->title ?? ''); ?>" id="title" name="title" placeholder="">
                                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span >
                                        <p style="color: red;"><?php echo e($message); ?></p>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div style="margin-bottom: 10px;" class="form-row">                 
                                <label for="description">Description</label>
                                <textarea rows="5" type="text" class="form-control" id="description" name="description" placeholder="">{! $post->description ?? '' !}</textarea>
                                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span >
                                        <p style="color: red;"><?php echo e($message); ?></p>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-12 col-md-6">
                                    <label for="image">Image</label>
                                    <input type="file" class="form-control" id="image" name="image" placeholder="Blog image" value="<?php echo e($post->image ?? ''); ?>">
                                    <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span >
                                            <p style="color: red;"><?php echo e($message); ?></p>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group col-12 col-md-6">
                                    <label for="img_desc">Image Description</label>
                                    <input type="text" class="form-control" id="img_desc" name="img_desc" placeholder="image description" value="<?php echo e($post->img_desc ?? ''); ?>">
                                    <?php $__errorArgs = ['img_desc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span >
                                            <p style="color: red;"><?php echo e($message); ?></p>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div style="margin-bottom: 10px;" class="form-row">
                                <label for="tags">Tags</label>
                                <input type="text" class="form-control" value="<?php echo e($post->tags ?? ''); ?>" id="tags" name="tags" placeholder="Music, Entertainment">
                                <?php $__errorArgs = ['img_desc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span >
                                        <p style="color: red;"><?php echo e($message); ?></p>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <?php echo e(csrf_field()); ?>

                            <button type="submit" class="btn btn-primary float-right">Update</button>
                            <?php if(isset($msg)): ?>
                                <span >
                                    <p style="color: green; text-align: center;"><?php echo e($msg); ?></p>
                                </span>
                            <?php endif; ?>   
                        </form>
                    </div>
                    <!-- End Form -->
                </div>
            </div>


        </div>

        <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\Mismo\blog\resources\views/admin/edit.blade.php ENDPATH**/ ?>