
    <?php $__env->startSection('comments', 'active'); ?>
    <?php $__env->startSection('content'); ?>

    <div class="content">
        <div class="py-4 px-3 px-md-4">
            <div class="card mb-3 mb-md-4">

                <div class="card-body">
                    <!-- Breadcrumb -->
                    <nav class="d-none d-md-block" aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">
                                <a href="#">Comments</a>
                            </li>
                            <li class="breadcrumb-item active" aria-current="page">View Comment</li>
                        </ol>
                    </nav>
                    <!-- End Breadcrumb -->

                    <div class="mb-3 mb-md-4 d-flex justify-content-between">
                        <div class="h3 mb-0">Comment</div>
                    </div>


                    <!-- Form -->
                    <div>
                        
                        	<div style="margin-bottom: 10px;" class="form-row">
                                <label for="name">Name</label>
                                <input readonly="true" type="text" class="form-control" value="<?php echo e($comment->name ?? ''); ?>" id="name" placeholder="">
                            </div>
                            <div style="margin-bottom: 10px;" class="form-row">                 
                                <label for="comment">Comment</label>
                                <textarea readonly="true" rows="5" type="text" class="form-control" value="" id="comment" placeholder=""><?php echo e($comment->comment ?? ''); ?></textarea>
                            </div>
                            <div style="margin-bottom: 10px;" class="form-row">
                                <label for="location">Location</label>
                                <input readonly="true" type="text" class="form-control" value="<?php echo e($comment->location ?? ''); ?>" id="location" placeholder="">
                            </div>
                            <?php if($comment->publish == "false"): ?>
                                <a href="/admin/publish/<?php echo e($comment->id); ?>"><button style="margin-left: 10px; background-color: green; border-color: green;"  class="btn btn-primary float-right">Publish</button></a>
                            <?php endif; ?>    
                            <a href="/admin/delete-comment/<?php echo e($comment->id); ?>"><button style="margin-left: 10px; background-color: red; border-color: red;"  class="btn btn-primary float-right">Delete</button></a>
                            <a href="/admin/view-post/<?php echo e($comment->post_id); ?>"><button class="btn btn-primary float-right">View Post</button></a>
                            <?php if(isset($msg)): ?>
                                <span >
                                    <p style="color: red; text-align: center;"><?php echo e($msg); ?></p>
                                </span>
                            <?php endif; ?>   
                    </div>
                    <!-- End Form -->
                </div>
            </div>


        </div>

        <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\Mismo\blog\resources\views/admin/view-comment.blade.php ENDPATH**/ ?>