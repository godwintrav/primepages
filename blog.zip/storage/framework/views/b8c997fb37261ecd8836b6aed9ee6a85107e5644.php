

  <?php $__env->startSection($active, 'active'); ?>
  <?php $__env->startSection('content'); ?>

    <!-- Page Content -->
    <!-- Banner Starts Here -->
    <div class="heading-page header-text">
      <section class="page-heading">
        <div class="container">
          <div class="row">
            <div class="col-lg-12">
              <div class="text-content">
                <h4><?php echo e($active); ?> Posts</h4>
                <h2>Our <?php echo e($active); ?> Blog Entries</h2>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
    
    <!-- Banner Ends Here -->

    <section class="blog-posts grid-system">
      <div class="container">
        <div class="row">
          <div class="col-lg-8">
            <div class="all-blog-posts">
              <div class="row">
                <?php if(isset($posts) && count($posts) >= 1): ?>
                  <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-6">
                      <div class="blog-post">
                        <div class="blog-thumb">
                          <a href="/view/<?php echo e($post->id); ?>"><img src="<?php echo e(asset('storage/'.$post->image ?? '')); ?>" alt=""></a>
                        </div>
                        <div class="down-content">
                          <?php
                            $tags = explode(",", $post->tags);
                          ?>
                          <span style="font-size: 14px;"><?php echo e($tags[0] ?? ''); ?></span>
                          <a href="/view/<?php echo e($post->id); ?>"><h4><?php echo e($post->title ?? ''); ?></h4></a>
                          <ul class="post-info">
                            <li><a href="/view/<?php echo e($post->id); ?>"><strong>Blog by: </strong>Topon Sharma</a></li>
                            <li><a href="/view/<?php echo e($post->id); ?>"><?php echo e($post->created_at->format('M d Y') ?? ''); ?></a></li>
                          </ul>
                          <p>
                          <?php if(strlen($post->description) > 200): ?>
                            <?php echo substr($post->description, 0 , 200); ?>.....
                          <?php else: ?>
                            <?php echo $post->description; ?>

                          <?php endif; ?> 
                          </p>
                          <div class="post-options">
                            <div class="row">
                              <div class="col-lg-12">
                                <ul class="post-tags">
                                  <li><i class="fa fa-tags"></i></li>
                                  <?php for($i = 0; $i < count($tags); $i++): ?>
                                    <li><a href="/search/<?php echo e($tags[$i]); ?>"><?php echo e($tags[$i]); ?></a><?php if($i < (count($tags) - 1 && !empty($tags[$i]))): ?>, <?php endif; ?></li>
                                  <?php endfor; ?>
                                </ul>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                  <h4>No Post Found</h4>
                <?php endif; ?>
                
                <!-- <div class="col-lg-12">
                  <ul class="page-numbers">
                    <li><a href="#">1</a></li>
                    <li class="active"><a href="#">2</a></li>
                    <li><a href="#">3</a></li>
                    <li><a href="#"><i class="fa fa-angle-double-right"></i></a></li>
                  </ul>
                </div> -->
              </div>
            </div>
          </div>
          <div class="col-lg-4">
            <div class="sidebar">
              <div class="row">
                <div class="col-lg-12">
                  <div class="sidebar-item search">
                    <form id="search_form" name="gs" method="GET" action="/search">
                      <input type="text" name="search" class="searchText" placeholder="type to search..." autocomplete="on">
                    </form>
                  </div>
                </div>
                <div class="col-lg-12">
                  <div class="sidebar-item recent-posts">
                    <!-- <div class="sidebar-heading">
                      <h2>Recent Posts</h2>
                    </div> -->
                    <div class="content">
                      <ul>
                        <?php if(isset($similiar_posts)): ?>
                          <?php $__currentLoopData = $similiar_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="/view/<?php echo e($post->id); ?>">
                              <h6 style="color: #f48840; font-weight: bold;"><?php echo e($post->title); ?></h6>
                              <span><?php echo e($post->created_at->diffforHumans() ?? ''); ?></span>
                            </a></li>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                      </ul>
                    </div>
                  </div>
                </div>
                <!-- <div class="col-lg-12">
                  <div class="sidebar-item categories">
                    <div class="sidebar-heading">
                      <h2>Categories</h2>
                    </div>
                    <div class="content">
                      <ul>
                        <li><a href="#">- Nature Lifestyle</a></li>
                        <li><a href="#">- Awesome Layouts</a></li>
                        <li><a href="#">- Creative Ideas</a></li>
                        <li><a href="#">- Responsive Templates</a></li>
                        <li><a href="#">- HTML5 / CSS3 Templates</a></li>
                        <li><a href="#">- Creative &amp; Unique</a></li>
                      </ul>
                    </div>
                  </div>
                </div> -->
                <div class="col-lg-12">
                  <div class="sidebar-item tags">
                    <div class="sidebar-heading">
                      <h2>Tag Clouds</h2>
                    </div>
                    <div class="content">
                      <ul>
                        <?php if(isset($all_tags)): ?>
                          <?php $__currentLoopData = $all_tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="/search/<?php echo e($tag); ?>"><?php echo e($tag); ?></a></li>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  <?php $__env->stopSection(); ?>
    
    
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\Mismo\blog\resources\views/blog.blade.php ENDPATH**/ ?>