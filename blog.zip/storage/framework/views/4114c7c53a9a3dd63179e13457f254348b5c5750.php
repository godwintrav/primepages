    <?php $__env->startSection('comments', 'active'); ?>
    <?php $__env->startSection('content'); ?>

    <div class="content">
        <div class="py-4 px-3 px-md-4">

            <div class="mb-3 mb-md-4 d-flex justify-content-between">
                <div class="h3 mb-0">Comments</div>
            </div>

            <div class="row">
                <div class="col-12">
                    <div class="card mb-3 mb-md-4">
                        <div class="card-header">
                            <h5 class="font-weight-semi-bold mb-0">Recent Comments</h5>
                        </div>

                        <div class="card-body pt-0">
                            <div class="table-responsive-xl">
                                <table class="table text-nowrap mb-0">
                                    <thead>
                                    <tr>
                                        <th class="font-weight-semi-bold border-top-0 py-2">#</th>
                                        <th class="font-weight-semi-bold border-top-0 py-2">Name</th>
                                        <th class="font-weight-semi-bold border-top-0 py-2">Comment</th>
                                        <!-- <th class="font-weight-semi-bold border-top-0 py-2">Amount</th> -->
                                        <th class="font-weight-semi-bold border-top-0 py-2">Status</th>
                                        <th class="font-weight-semi-bold border-top-0 py-2">Actions</th>
                                    </tr>
                                    </thead>
                                    <tbody>

                                    <?php if(isset($comments)): ?>
                                        <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <tr>
                                                <td class="py-3"><?php echo e($i); ?></td>
                                                <td class="py-3">
                                                    <div><?php echo e($comment->name); ?></div>
                                                    <div class="text-muted"><?php echo e($comment->location); ?></div>
                                                </td>
                                                <td class="py-3">
                                                    <?php if(strlen($comment->comment) > 50): ?>
                                                        <?php echo e(substr($comment->comment, 0 , 50)); ?>.....
                                                    <?php else: ?>
                                                        <?php echo e($comment->comment); ?>

                                                    <?php endif; ?>    
                                                </td>
                                                <!-- <td class="py-3">$1,230.00</td> -->
                                                <td class="py-3">
                                                    <?php if($comment->publish == "false"): ?>
                                                        <span class="badge badge-pill badge-warning">Pending</span>
                                                    <?php else: ?>
                                                        <span class="badge badge-pill badge-success">Published</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td class="py-3">
                                                    <div class="position-relative">
                                                        <a id="dropDown<?php echo e($comment->id); ?>Invoker" class="link-dark d-flex" href="#" aria-controls="dropDown<?php echo e($comment->id); ?>" aria-haspopup="true" aria-expanded="false" data-unfold-target="#dropDown<?php echo e($comment->id); ?>" data-unfold-event="click" data-unfold-type="css-animation" data-unfold-duration="300" data-unfold-animation-in="fadeIn" data-unfold-animation-out="fadeOut">
                                                            <i class="gd-more-alt icon-text"></i>
                                                        </a>

                                                        <ul id="dropDown<?php echo e($comment->id); ?>" class="unfold unfold-light unfold-top unfold-right position-absolute py-3 mt-1 unfold-css-animation unfold-hidden fadeOut" aria-labelledby="dropDown<?php echo e($comment->id); ?>Invoker" style="min-width: 150px; animation-duration: 300ms; right: 0px;">
                                                            <li class="unfold-item">
                                                                <a class="unfold-link media align-items-center text-nowrap" href="/admin/comment/<?php echo e($comment->id); ?>">
                                                                    <i class="gd-eye unfold-item-icon mr-3"></i>
                                                                    <span class="media-body">View comment</span>
                                                                </a>
                                                            </li>
                                                            <?php if($comment->publish == "false"): ?>
                                                                <li class="unfold-item">
                                                                    <a class="unfold-link media align-items-center text-nowrap" href="/admin/publish/<?php echo e($comment->id); ?>">
                                                                        <i class="gd-pencil unfold-item-icon mr-3"></i>
                                                                        <span class="media-body">Publish</span>
                                                                    </a>
                                                                </li>
                                                            <?php endif; ?>
                                                            <li class="unfold-item">
                                                                <a class="unfold-link media align-items-center text-nowrap" href="/admin/delete-comment/<?php echo e($comment->id); ?>">
                                                                    <i class="gd-close unfold-item-icon mr-3"></i>
                                                                    <span class="media-body">Delete</span>
                                                                </a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </td>
                                            </tr>
                                            <?php
                                                $i++;
                                            ?>  

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>   

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


        </div>

        <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\Mismo\blog\resources\views/admin/comments.blade.php ENDPATH**/ ?>