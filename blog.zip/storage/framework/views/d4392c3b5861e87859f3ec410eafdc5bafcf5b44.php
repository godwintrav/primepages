

  <?php $__env->startSection('index', 'active'); ?>
  <?php $__env->startSection('content'); ?>

    <!-- Page Content -->
    <!-- Banner Starts Here -->
    <div class="main-banner header-text">
      <div class="container-fluid">
        <div class="owl-banner owl-carousel">

        <?php if(isset($top_posts)): ?>
          <?php $__currentLoopData = $top_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="item">
            <a href="/view/<?php echo e($post->id); ?>"><img src="<?php echo e(asset('storage/'.$post->image ?? '')); ?>" alt=""></a>
              <div class="item-content">
                <div class="main-content">
                  <div class="meta-category">              
                  </div>
                  <a href="/view/<?php echo e($post->id); ?>"><h5 style="color: white; font-style: italic;"><?php echo e($post->title ?? ''); ?></h5></a>
                  <ul class="post-info">
                    <!-- <li style="font-size: 14px;"><a  href="#">Admin</a></li> -->
                    <li style="color: white;"><?php echo e($post->created_at->diffforHumans() ?? ''); ?></li>
                    <li style="color: white;">12 Comments</li>
                  </ul>
                </div>
              </div>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?> 

        </div>
      </div>
    </div>
    <!-- Banner Ends Here -->


    <section class="blog-posts">
      <div class="container">
        <div class="row">
          <div class="col-lg-8">
            <div class="all-blog-posts">
              <div class="row">

              <?php if(isset($posts) && count($posts) >= 1): ?>
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="col-lg-12">
                    <div class="blog-post">
                      <div class="blog-thumb">
                      <a href="/view/<?php echo e($post->id); ?>"><img src="<?php echo e(asset('storage/'.$post->image ?? '')); ?>"></a>
                      </div>
                      <div class="down-content">
                        <?php
                          $tags = explode(",", $post->tags);
                        ?>
                        <span style="font-size: 14px;"><?php echo e($tags[0] ?? ''); ?></span>
                        <a href="/view/<?php echo e($post->id); ?>"><h4><?php echo e($post->title ?? ''); ?></h4></a>
                        <ul class="post-info">
                          <li><a href="/view/<?php echo e($post->id); ?>">Admin</a></li>
                          <li><a href="/view/<?php echo e($post->id); ?>"><?php echo e($post->created_at->format('M d Y') ?? ''); ?></a></li>
                          <li><a href="/view/<?php echo e($post->id); ?>">12 Comments</a></li>
                        </ul>
                        <p><?php echo e(substr($post->description, 0, 300).'...'); ?></p>
                        <div class="post-options">
                          <div class="row">
                            <div class="col-6">
                              <ul class="post-tags">
                              <li><i class="fa fa-tags"></i></li>
                              <?php for($i = 0; $i < count($tags); $i++): ?>
                                <li><a href="/search/<?php echo e($tags[$i]); ?>"><?php echo e($tags[$i]); ?></a><?php if($i < (count($tags) - 1 && !empty($tags[$i]))): ?>, <?php endif; ?></li>
                              <?php endfor; ?>
                              </ul>
                            </div>
                            <div class="col-6">
                              <ul class="post-share">
                                <li><i class="fa fa-share-alt"></i></li>
                                <li><a href="">Facebook</a>,</li>
                                <li><a href=""> Twitter</a></li>
                              </ul>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                  <h4 style="margin: 0 auto;">No Post Found</h4>
              <?php endif; ?>   
                
                <div class="col-lg-12">
                  <div class="main-button">
                    <a href="/recent">View All Posts</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-4">
            <div class="sidebar">
              <div class="row">
                <div class="col-lg-12">
                  <div class="sidebar-item search">
                    <form id="search_form" name="gs" method="GET" action="/search">
                    <input type="text" name="search" class="searchText" placeholder="type to search..." autocomplete="on">
                    </form>
                  </div>
                </div>
                <div class="col-lg-12">
                  <div class="sidebar-item recent-posts">
                    <div class="sidebar-heading">
                      <h2>Recent Posts</h2>
                    </div>
                    <div class="content">
                      <ul>
                        <?php if(isset($similiar_posts)): ?>
                          <?php $__currentLoopData = $similiar_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="/view/<?php echo e($post->id); ?>">
                              <h6 style="color: #f48840; font-weight: bold;"><?php echo e($post->title); ?></h6>
                              <span><?php echo e($post->created_at->diffforHumans() ?? ''); ?></span>
                            </a></li>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                      </ul>
                    </div>
                  </div>
                </div>
                <!-- <div class="col-lg-12">
                  <div class="sidebar-item categories">
                    <div class="sidebar-heading">
                      <h2>Categories</h2>
                    </div>
                    <div class="content">
                      <ul>
                        <li><a href="#">- Nature Lifestyle</a></li>
                        <li><a href="#">- Awesome Layouts</a></li>
                        <li><a href="#">- Creative Ideas</a></li>
                        <li><a href="#">- Responsive Templates</a></li>
                        <li><a href="#">- HTML5 / CSS3 Templates</a></li>
                        <li><a href="#">- Creative &amp; Unique</a></li>
                      </ul>
                    </div>
                  </div>
                </div> -->
                <div class="col-lg-12">
                  <div class="sidebar-item tags">
                    <div class="sidebar-heading">
                      <h2>Tag Clouds</h2>
                    </div>
                    <div class="content">
                      <ul>
                        <?php if(isset($all_tags)): ?>
                          <?php $__currentLoopData = $all_tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tags): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="/search/<?php echo e($tags); ?>"><?php echo e($tags); ?></a></li>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>  
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  <?php $__env->stopSection(); ?>
    
    
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\Mismo\blog\resources\views/index.blade.php ENDPATH**/ ?>